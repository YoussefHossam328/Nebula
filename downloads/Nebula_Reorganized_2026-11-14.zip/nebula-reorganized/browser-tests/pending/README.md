# Pending Manus feature tests

`polish.spec.ts` (four tests), `survival.spec.ts` (five tests), and the updated `authored-base.spec.ts` (one test) were supplied with standalone feature modules, but the corresponding updated core game and generated terrain/APOD files were not included. The recovered `main.ts` and `mission.ts` are identical to the old nested archive and do not expose the newer actions/UI these tests require.

The root Playwright config excludes this directory explicitly. Keep these tests: they are useful acceptance criteria for recovering the missing integration. After restoring the full Manus source and required public data, remove that exclusion and replace the active baseline authored-base test with its supplied updated version and rerun the original 24-test Manus suite. Do not treat the current 15-test baseline run as confirmation of the missing integration.
