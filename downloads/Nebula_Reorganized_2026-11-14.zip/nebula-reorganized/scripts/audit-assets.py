#!/usr/bin/env python3
"""Check the restored project's actual GLB contracts without third-party packages."""
import json,struct,sys
from pathlib import Path
ROOT=Path(__file__).resolve().parents[1]
CONTRACTS={'Base.glb':{'nodes':['base']},'Lander.glb':{},'SolarPanel.glb':{'nodes':['SolarBase','Panel'],'materials':['Clean','Dirty']},'player.glb':{'animations':['Idle','walk again']}}
rows=[];errors=[]
for name,contract in CONTRACTS.items():
 p=ROOT/'public/models'/name
 if not p.exists():errors.append(f'Missing {p.relative_to(ROOT)}');continue
 b=p.read_bytes()
 try:
  magic,version,length=struct.unpack_from('<4sII',b);assert magic==b'glTF' and version==2 and length==len(b)
  n,kind=struct.unpack_from('<I4s',b,12);assert kind==b'JSON';j=json.loads(b[20:20+n])
  row=dict(file='public/models/'+name,bytes=len(b),nodes=[v.get('name','') for v in j.get('nodes',[])],materials=[v.get('name','') for v in j.get('materials',[])],animations=[v.get('name','') for v in j.get('animations',[])])
  for field,expected in contract.items():
   for value in expected:
    if not any(value.lower() in found.lower() for found in row[field]):errors.append(f'{name}: missing {field} entry {value}')
  for entry in j.get('buffers',[])+j.get('images',[]):
   uri=entry.get('uri','')
   if uri and not uri.startswith('data:'):
    if '://' in uri:errors.append(f'{name}: external network resource {uri}')
    elif not (p.parent/uri).exists():errors.append(f'{name}: missing sidecar {uri}')
  rows.append(row)
 except Exception as ex:errors.append(f'Invalid GLB {name}: {ex}')
print(json.dumps(dict(models=rows,errors=errors),indent=2));sys.exit(bool(errors))
