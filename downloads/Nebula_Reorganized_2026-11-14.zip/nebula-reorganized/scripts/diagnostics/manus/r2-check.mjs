import { chromium } from "@playwright/test";
const URL = process.env.URL ?? "http://127.0.0.1:3000/";
const out = "/home/ubuntu/shots2";
const b = await chromium.launch({ args: ["--use-gl=angle", "--use-angle=swiftshader", "--enable-unsafe-swiftshader"] });
const p = await b.newPage({ viewport: { width: 1280, height: 760 } });
const errors = [];
p.on("pageerror", (e) => errors.push(e.message));
p.on("console", (m) => m.type() === "error" && errors.push(m.text()));
await p.goto(URL);
await p.waitForFunction(() => window.nebula?.ready, null, { timeout: 90000 });
await p.getByRole("button", { name: /seven-sol|challenge|mission/i }).first().click();
await p.waitForTimeout(800);
const st = () => p.evaluate(() => ({ game: window.nebula.game, base: window.nebula.base, harvest: window.nebula.harvest, o2: window.nebula.oxygenPlant }));
console.log("mission", JSON.stringify((await st()).base));
// Outside oxygen drains.
await p.evaluate(() => window.nebula.actions.teleport(8, 6));
await p.waitForTimeout(2500);
const o1 = (await st()).base.oxygen;
await p.waitForTimeout(2500);
const o2 = (await st()).base.oxygen;
console.log("outside oxygen", o1, "->", o2, "sheltered", (await st()).base.sheltered);
// Crop beds: inside habitat at farm.
await p.evaluate(() => window.nebula.actions.teleport(1.9, -9.0));
await p.waitForTimeout(1500);
const s2 = await st();
console.log("at farm sheltered", s2.base.sheltered, "crops", s2.base.crops);
await p.locator("#world").focus();
await p.keyboard.press("KeyE");
await p.waitForTimeout(900);
console.log("harvest", JSON.stringify((await st()).harvest));
await p.screenshot({ path: `${out}/r2-harvest-open.png` });
// Swipe across the stage a few times with the mouse.
const box = await p.locator("#harvest-game canvas").boundingBox();
if (box) {
  for (let k = 0; k < 6; k++) {
    const y = box.y + box.height * (0.25 + 0.1 * k);
    await p.mouse.move(box.x + box.width * 0.05, y);
    await p.mouse.down();
    await p.mouse.move(box.x + box.width * 0.95, y + 20, { steps: 12 });
    await p.mouse.up();
  }
}
await p.waitForTimeout(300);
await p.screenshot({ path: `${out}/r2-harvest-mid.png` });
console.log("harvest after swipes", JSON.stringify((await st()).harvest));
await p.keyboard.press("Escape");
await p.waitForTimeout(500);
// Oxygen plant with forced punctures.
await p.evaluate(() => window.nebula.actions.teleport(-6.4, 0.6));
await p.waitForTimeout(1200);
await p.evaluate(() => {
  // inject 2 punctures via debug hook if present
});
await p.locator("#world").focus();
await p.keyboard.press("KeyE");
await p.waitForTimeout(900);
console.log("o2", JSON.stringify((await st()).o2), "punct", (await st()).base.punctures);
const ob = await p.locator("#oxygen-game canvas").boundingBox();
if (ob) {
  await p.mouse.move(ob.x + ob.width * 0.4, ob.y + ob.height * 0.3);
  await p.mouse.down();
  await p.mouse.move(ob.x + ob.width * 0.7, ob.y + ob.height * 0.5, { steps: 20 });
  await p.mouse.up();
}
await p.waitForTimeout(400);
await p.screenshot({ path: `${out}/r2-oxygen.png` });
await p.keyboard.press("Escape");
await p.waitForTimeout(400);
// Twilight sweep: screenshots at a few times of day.
for (const h of [17.2, 18.4, 19.6]) {
  await p.evaluate((h) => {
    const sim = window.__nebulaSim;
    if (sim) sim.elapsed = Math.floor(sim.elapsed / 88775) * 88775 + h * 3699;
  }, h);
  await p.waitForTimeout(1500);
  await p.screenshot({ path: `${out}/r2-dusk-${h}.png` });
}
console.log("errors", JSON.stringify(errors.slice(0, 8)));
await b.close();
