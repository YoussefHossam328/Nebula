import { chromium } from "@playwright/test";
import fs from "node:fs";

const out = "/home/ubuntu/nebula/shots";
fs.mkdirSync(out, { recursive: true });

const browser = await chromium.launch({
  args: ["--use-gl=angle", "--use-angle=swiftshader", "--enable-unsafe-swiftshader"],
});
const page = await browser.newPage({ viewport: { width: 1440, height: 900 } });
const errors = [];
page.on("pageerror", (e) => errors.push(String(e)));
page.on("console", (m) => { if (m.type() === "error") errors.push(m.text()); });

await page.goto("http://127.0.0.1:5173/Nebula/", { waitUntil: "networkidle" });
await page.waitForFunction(() => window.nebula?.ready, null, { timeout: 60000 });
await page.waitForTimeout(1500);
await page.screenshot({ path: `${out}/01-menu.png` });

await page.getByRole("button", { name: "Play", exact: true }).click();
await page.waitForTimeout(500);
await page.screenshot({ path: `${out}/02-tutorial-dialogue.png` });

await page.getByRole("button", { name: "Try it", exact: true }).click();
await page.waitForTimeout(1200);
await page.screenshot({ path: `${out}/03-tutorial-world.png` });

await page.keyboard.press("Escape");
await page.waitForTimeout(400);
await page.screenshot({ path: `${out}/04-paused.png` });

await page.getByRole("button", { name: "Main menu", exact: true }).click();
await page.waitForTimeout(300);
await page.getByRole("button", { name: "Start challenge", exact: true }).click();
await page.waitForTimeout(2500);
await page.screenshot({ path: `${out}/05-mission.png` });

// Walk toward the base for a different angle
await page.keyboard.down("KeyW");
await page.waitForTimeout(2500);
await page.keyboard.up("KeyW");
await page.waitForTimeout(500);
await page.screenshot({ path: `${out}/06-mission-walk.png` });

const state = await page.evaluate(() => ({
  game: window.nebula.game,
  base: window.nebula.base,
  position: window.nebula.position,
  station: window.nebula.station,
  solar: window.nebula.solar,
}));
console.log(JSON.stringify({ state, errors }, null, 2));

// Legacy sandbox
const lab = await browser.newPage({ viewport: { width: 1440, height: 900 } });
await lab.goto("http://127.0.0.1:5173/Nebula/?lab", { waitUntil: "networkidle" });
await lab.waitForFunction(() => window.nebula?.ready, null, { timeout: 60000 });
await lab.waitForTimeout(1500);
await lab.screenshot({ path: `${out}/07-lab.png` });

// Mobile menu
const mobile = await browser.newPage({ viewport: { width: 390, height: 844 }, deviceScaleFactor: 2 });
await mobile.goto("http://127.0.0.1:5173/Nebula/", { waitUntil: "networkidle" });
await mobile.waitForFunction(() => window.nebula?.ready, null, { timeout: 60000 });
await mobile.waitForTimeout(1000);
await mobile.screenshot({ path: `${out}/08-mobile-menu.png` });

await browser.close();
