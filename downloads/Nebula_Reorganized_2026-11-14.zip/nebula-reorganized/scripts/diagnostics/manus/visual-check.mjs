import { chromium } from "@playwright/test";
const out = "/home/ubuntu/shots2";
const url = process.env.URL ?? "http://localhost:3000/";
const browser = await chromium.launch({ args: ["--use-gl=angle", "--use-angle=swiftshader", "--enable-unsafe-swiftshader"] });
const page = await browser.newPage({ viewport: { width: 1280, height: 760 } });
const errors = [];
page.on("console", (m) => m.type() === "error" && errors.push(m.text()));
page.on("pageerror", (e) => errors.push(String(e)));
await page.goto(url);
await page.screenshot({ path: `${out}/00-boot.png` });
await page.waitForFunction(() => (window).nebula?.game, null, { timeout: 60000 });
await page.waitForTimeout(1200);
await page.screenshot({ path: `${out}/01-menu.png` });
const n = () => page.evaluate(() => (window).nebula);
console.log("menu buttons", await page.$$eval("#game-overlay button", (b) => b.map((x) => x.textContent)));
// Start challenge
await page.getByRole("button", { name: /challenge/i }).first().click();
await page.waitForTimeout(800);
// Skip mission intro dialogs if any
for (let i = 0; i < 6; i++) {
  const btn = page.locator("#game-overlay:not([hidden]) button").first();
  if (await btn.count() && await btn.isVisible()) { await btn.click(); await page.waitForTimeout(300); } else break;
}
await page.waitForTimeout(1500);
await page.screenshot({ path: `${out}/02-mission.png` });
// Teleport to array service ring
const info = await n();
console.log("state", info.game, "dust", info.dust, "model", JSON.stringify(info.model ?? info.player?.model ?? {}).slice(0, 300));
await page.evaluate(() => {
  const w = window;
  w.nebula.actions?.teleport?.(0, 0);
});
await page.waitForTimeout(400);
console.log("prompt", await page.locator("#mission-prompt").textContent());
// Crouch + jump poses
await page.keyboard.down("KeyC");
await page.waitForTimeout(700);
await page.screenshot({ path: `${out}/03-crouch.png` });
await page.keyboard.up("KeyC");
await page.keyboard.down("Space");
await page.waitForTimeout(250);
await page.screenshot({ path: `${out}/04-jump.png` });
await page.keyboard.up("Space");
await page.waitForTimeout(1200);
console.log("errors", errors.slice(0, 8));
await browser.close();
