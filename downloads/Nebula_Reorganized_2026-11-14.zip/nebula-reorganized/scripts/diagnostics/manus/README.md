# Supplied diagnostic helpers

These scripts are preserved from the Manus download. They contain exploratory screenshots, old absolute output paths and assumptions about ports and newer debug actions. They are not part of the default build/test commands. Review and update their paths/URLs before running them against a recovered full Manus build.
