import { defineConfig } from "vite";
export default defineConfig({
  base: "/Nebula/",
  server: { host: "0.0.0.0", port: 5174, allowedHosts: true },
});
