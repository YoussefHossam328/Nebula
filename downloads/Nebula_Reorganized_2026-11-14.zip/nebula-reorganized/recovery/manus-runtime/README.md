# Deferred runtime migration files

These files were loose in the upload. The split-WASM loader needs the non-compat Rapier package and a matching Vite alias/initialization strategy that were not included. They are preserved here but are not imported by the recovered application. The active build uses the supplied locked `@dimforge/rapier3d-compat` package consistently. Do not mix independently initialized Rapier package instances.
