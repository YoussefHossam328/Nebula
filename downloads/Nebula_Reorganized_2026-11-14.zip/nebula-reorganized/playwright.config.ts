import { defineConfig } from "@playwright/test";
const port = Number(process.env.NEBULA_TEST_PORT ?? 4173);
export default defineConfig({
  workers: 1,
  testDir: "./browser-tests",
  testIgnore: "**/pending/**",
  use: {
    baseURL: `http://127.0.0.1:${port}/Nebula/`,
    launchOptions: {
      args: [
        "--use-gl=angle",
        "--use-angle=swiftshader",
        "--enable-unsafe-swiftshader",
      ],
    },
  },
  webServer: {
    command: `npm run preview -- --port ${port}`,
    url: `http://127.0.0.1:${port}/Nebula/`,
    reuseExistingServer: !process.env.CI,
  },
});
