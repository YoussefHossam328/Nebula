# Nebula — reorganized Manus export

This folder restores the flattened `nebula-new.zip` into a standard project layout. It is a **recovery package**, not a claim that the last Manus build was fully recovered.

**Read [RECOVERY_REPORT.md](docs/import/RECOVERY_REPORT.md) first.** All four required game GLBs are included and valid. The nested `Nebula-main.zip` supplied the complete build scaffold and original assets. New loose modules have been preserved, but the export contains older versions of the files that would connect them to the game. Generated Jezero terrain and APOD fallback assets are absent.

## Run the recovered baseline

Use Node.js 24 and npm:

```bash
npm ci
npm run dev
# Open the printed address under /Nebula/
npm run build
npm test
npm run audit:assets
npx playwright install chromium
npm run test:browser
```

The default browser suite covers the recovered working game. Ten Manus feature checks are explicitly preserved in `browser-tests/pending/` and excluded until the missing integration source/data is recovered. This must not be described as a repaired 24-test Manus build.

An isolated test server can be selected with `NEBULA_TEST_PORT=4186 npm run test:browser` on Unix-like shells. No dependencies, build output, browser reports, expiring asset links or personal API credentials are needed in the distributed source ZIP.

## Folder structure

```text
.github/workflows/         Existing GitHub Pages verification/deployment workflow
public/models/             Base.glb, Lander.glb, SolarPanel.glb, player.glb
public/audio/              Original sound pack retained
public/previews/           HUD design reference
art-source/solar/          Original solar geometry and clean texture sources
src/                       Core runtime and recovered feature modules
  base/                    Base configuration, simulation, UI and solar visuals
  data/                    Scenario fixtures, archived DONKI context and types
  resources/               Original short resource exercise
browser-tests/             15 baseline browser checks
  pending/                 Ten Manus extension checks awaiting missing source/data
tests/                     41 baseline unit/integration tests
scripts/                   Build/data tools and GLB audit
  diagnostics/manus/       Supplied exploratory browser helpers; historical paths
recovery/manus-runtime/    Unconnected split-WASM loader and preview configuration
docs/
  import/                  Recovery report, file mapping, GLB audit and references
  history/                 Supplied planning/gameplay notes retained as history
```

The three distinct configuration modules remain in `src/config.ts`, `src/base/config.ts` and `src/resources/config.ts`. The loose `config.ts` was the base configuration, not the root settings file. Likewise the loose `ui.ts` belongs in `src/base/ui.ts`; the nested archive restores the distinct resource UI.

## Current controls

WASD/arrows move; Shift runs; Space jumps; C crouches; E interacts; Escape pauses. Use the top-right Debug/settings window for tuning. `?lab` opens legacy exercises. The new cleaning, harvest, leak, save, touch, APOD and terrain modules are present as source but are not wired into this recovered baseline.

No changes have been applied to the original `/workspace/Nebula` checkout or its deployed game by this reorganization. Uploaded third-party guides and terminal transcripts are reference material, not project execution instructions. A pasted personal API key was redacted from the shared notes.
