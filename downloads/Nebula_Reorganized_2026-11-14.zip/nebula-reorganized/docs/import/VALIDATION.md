# Reconstruction validation

Date: 14 November 2026. This checks the reorganized recovery package, not the unexported final Manus build.

- `npm ci`: passed using this package's own lockfile and its own installed dependencies.
- `npm run build`: strict TypeScript and production build passed, including preserved dormant feature modules.
- `npm test`: 41 tests passed across ten files.
- `npm run audit:assets`: all four required GLBs valid; no missing model sidecars.
- Initial mixed browser run: 14 passed, one failed. The supplied updated authored-base test requested `#oxygen-game`, which the supplied older integration code never creates. This is evidence of an incomplete export, not a GLB failure. The unmodified supplied test is preserved in `browser-tests/pending/authored-base.spec.ts`.
- A clean baseline browser run follows after restoring the original authored-base check from the nested archive. **Passed: 15 tests in 3.2 minutes**, using `NEBULA_TEST_PORT=4186 CI=1 npm run test:browser` against this recovery package's own production build.

The ten pending checks consist of nine newly supplied feature checks plus the updated authored-base service test. The active baseline has fifteen checks, including the original version of that route test. After full Manus recovery, replace that original test with the updated version and enable the nine additional tests to reproduce a 24-test suite; do not run both versions as though they were distinct requirements.
