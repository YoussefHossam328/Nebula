# Nebula round 2 (user requests 1-8) — findings & plan
Project /home/ubuntu/nebula, dev server PORT 3000 (session "dev"), tests: npx playwright test (preview 4173 root), npx vitest run.
Checkpoint flow: git reset -q (clean index) -> GIT_AUTHOR/COMMITTER Manus agent@manus.im node $GAME_RUNTIME/save-threejs.mjs --message ... -> git fetch origin main; merge --ff-only; git push origin HEAD:main. GAME_RUNTIME=/home/ubuntu/.manus-addons/manus-webdev-sha-0ad167e2d688b0e4/runtime/game-dev

## Findings
- player.glb clips: "Action.001" = clean seamless in-place walk (1.6s). "walk again" (currently used) has a BROKEN first keyframe (LeftLeg 58deg, arms 45-50deg pop) at loop seam -> stutter every 1.62s. "Armature.001|mixamo.com|Layer0" = authored JUMP (2.62s: crouch, leap, tuck, land). "Idle" 8.35s clean. No run clip.
- walk again root motion: hips z 1.32 raw units per cycle; natural speed ~0.7 m/s in world; settings walk 2.5, run 4.5, walkStepDistance .8, runStepDistance 1.1 (distance-based audio, unrelated to anim) -> mismatch.
- Diag in headless: grounded flips negligible (not cause). Headless ~10fps can't measure frame timing.
- Stress only from dose: baseline 0.21 mGy/sol*15 = ~3%/sol -> meter looks dead until particle event (sol 3, 8h, 8.1 mGy; limit 5).
- Shelter = transparent box at (6,5) 4x4 (base/visuals.ts) + label; base.sim.isSheltered box test; base/ui.ts tick passes sim.isSheltered(p).
- Habitat inside test exists in authored-station.ts update(): circles (2,-1),(-7,-1),(2,-9.6) r3 + corridors, y<2.7. Oxygen plant (-6.4,-0.3) & farm (1.9,-10) are inside; array (-8,5) & beacon (3,2) outside.
- Oxygen: rate = (powered?prod 0.05:0) - cons 0.035 kg/h regardless of location.
- Day/night: main.ts day=smoothstep(elev,-0.08,0.18) ~1 sim hour (~7 real s); body.night CSS toggles instantly. realSecondsPerSol 180 default; localStorage nebula.base may persist 180 -> migrate to 120.

## Plan
1/2 shelter=habitat (insideHabitat in layout.ts), remove box in mission (keep ?lab). Stress: + EVA strain outside, recovers inside, high stress raises O2 use; HUD rad rate + geiger clicks.
3 outside: no maker output, EVA consumption drains.
4 use Action.001; remove per-frame audio automation churn.
5 crop harvest minigame (shears drag-cut stems of ripe produce, falls into basket; unripe = wasted).
6 O2 plant panel: maker switch + punctures (scheduled leaks drain O2); find leaks w/ soap spray (bubbles) + hiss hint, seal by circling cursor to wind tape.
7 gradual twilight wide smoothstep, 120 s/sol.
8 derived run clip (amplified walk around mean pose + lean), timeScale=speed/natural, footsteps from anim phase (foot separation extrema).
