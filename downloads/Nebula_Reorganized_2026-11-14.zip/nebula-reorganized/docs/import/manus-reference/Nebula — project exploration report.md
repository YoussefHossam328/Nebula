# Nebula — project exploration report

**Snapshot:** `Nebula-main.zip`, extracted to `/home/ubuntu/nebula/Nebula-main`  
**Type:** Browser game / educational simulation — Three.js renderer + Rapier physics  
**Context:** Junior Astronaut Mission Trainer, NASA Space Apps Challenge 2026  
**Codebase:** ~3,900 lines of TypeScript/CSS in 30 source files, plus 6 design documents, 41 unit tests and 15 Playwright tests

![Nebula title screen](https://private-us-east-1.manuscdn.com/sessionFile/6E54TNmq5u8RErGC3f6Mds/sandbox/b3cwZ2mTTU2sxjH7GUAWfn-images_1794636574759_na1fn_L2hvbWUvdWJ1bnR1L25lYnVsYS9zaG90cy8wMS1tZW51.png?Policy=eyJTdGF0ZW1lbnQiOlt7IlJlc291cmNlIjoiaHR0cHM6Ly9wcml2YXRlLXVzLWVhc3QtMS5tYW51c2Nkbi5jb20vc2Vzc2lvbkZpbGUvNkU1NFRObXE1dThSRXJHQzNmNk1kcy9zYW5kYm94L2IzY3daMm1UVFUyc3hqSDdHVUFXZm4taW1hZ2VzXzE3OTQ2MzY1NzQ3NTlfbmExZm5fTDJodmJXVXZkV0oxYm5SMUwyNWxZblZzWVM5emFHOTBjeTh3TVMxdFpXNTEucG5nIiwiQ29uZGl0aW9uIjp7IkRhdGVMZXNzVGhhbiI6eyJBV1M6RXBvY2hUaW1lIjoxNzk2MDgzMjAwfX19XX0_&Key-Pair-Id=K2QY5QTL8JSY6C&Signature=MEUCIQCJJrnCZJ5jagXKrJczNQqTaFvlYsaw2UZ0NEnJ9pa~7QIgZ8G4aLp7rtdBpjnosyKfekYLlLajbNmHk8wxsxH1pAM_)

## What it is

Nebula is a keyboard-first, low-poly Mars survival field lab. The player is an astronaut at a small outpost and must keep it alive for **seven Mars sols** by managing power, oxygen, food, dust and radiation. It is a compact, systems-driven educational game rather than an open-world exploration title: the station has a habitat, an oxygen utility room, two crop beds, a tracking solar array, a storm shelter and a landed vehicle.

The project is unusually complete for a prototype. It has a title screen, eight action-gated tutorials, a full seven-sol challenge, pause/results flows, a debug/tuning window, procedural audio, GLB asset handoff hooks, local-storage settings, JSON import/export, and GitHub Pages CI/CD.

## Verification performed

| Check | Result |
| --- | --- |
| `npm ci` | Installed 55 packages cleanly |
| `npm run typecheck` | Passed, no TypeScript errors |
| `npm test` | **41/41 unit tests passed** (10 files) |
| `npm run build` | Passed; single JS bundle **5.11 MB** (1.87 MB gzip), CSS 7.22 kB |
| `npm run test:browser` | **15/15 Playwright tests passed** |
| Live boot in Chromium | `window.nebula.ready`, player model, base GLB and solar GLB all loaded; no console errors |

The project expects **Node 24** (`.nvmrc`), but ran without issue on Node 22.23.4.

## How to run

```bash
cd Nebula-main
npm ci
npm run dev        # Vite serves at /Nebula/
# open the printed URL + /Nebula/
```

Production: `npm run build`, then `npm run preview -- --port 4173`. The Vite base path is hard-coded to `/Nebula/` for GitHub Pages.

**Controls:** WASD/arrows move, Shift runs, Space jumps, C crouches, E interacts, R resets position. Hold E at the cyan solar ring to clean the array. Escape pauses.

## Game flow

```text
Title screen (Play / Start challenge)
   └─ Play → 8 tutorials (dialogue → action → recap)
   │     1 Move/run/jump/crouch
   │     2 Solar power and battery
   │     3 Clean dust from panels
   │     4 Oxygen production vs. load
   │     5 Harvest a crop
   │     6 Shelter from radiation
   │     7 Delayed Earth reply
   │     8 Mission briefing
   └─ Start challenge → 7-sol survival run → victory or loss screen
```

The tutorials isolate the mechanic being taught: survival time is paused during dialogue, supplies have safety floors, and only the relevant system advances. The challenge resets supplies and runs the deterministic weather/radiation calendar.

### Default challenge numbers

| System | Defaults |
| --- | --- |
| Scenario | 7 sols, 180 real seconds per sol (~21 min) |
| Solar array | 60 m², 22% efficiency, 500 W/m² peak, dual-axis tracking, 10 W tracking draw |
| Battery | 24 kWh capacity, 80% initial charge, 6 kW charge/discharge limits, 95% efficiencies |
| Base load | 180 W base + 1.5 kW oxygen plant + 80 W shelter when occupied |
| Oxygen | 4 kg capacity, 2 kg start, 0.035 kg/h consumption, 0.05 kg/h production |
| Dust | 90% initial transmission, 4% loss per sol, 4-second hold to clean |
| Radiation | 0.21 mGy/day baseline + reconstructed 8.1 mGy event on sol 3, 5 mGy run limit |
| Stress (fictional) | +15 per mGy, −6 per sheltered simulated hour |
| Food | 80 nourishment start, −25 per sol, +35 per meal, two beds, 1 sol regrowth, 400 W growing load |
| Weather | Dust sol 1, cold snap sol 2, particle event sol 3, strong dust sol 5 |

## Architecture

![Module architecture](https://private-us-east-1.manuscdn.com/sessionFile/6E54TNmq5u8RErGC3f6Mds/sandbox/b3cwZ2mTTU2sxjH7GUAWfn-images_1794636574759_na1fn_L2hvbWUvdWJ1bnR1L25lYnVsYS9hcmNoaXRlY3R1cmUz.png?Policy=eyJTdGF0ZW1lbnQiOlt7IlJlc291cmNlIjoiaHR0cHM6Ly9wcml2YXRlLXVzLWVhc3QtMS5tYW51c2Nkbi5jb20vc2Vzc2lvbkZpbGUvNkU1NFRObXE1dThSRXJHQzNmNk1kcy9zYW5kYm94L2IzY3daMm1UVFUyc3hqSDdHVUFXZm4taW1hZ2VzXzE3OTQ2MzY1NzQ3NTlfbmExZm5fTDJodmJXVXZkV0oxYm5SMUwyNWxZblZzWVM5aGNtTm9hWFJsWTNSMWNtVXoucG5nIiwiQ29uZGl0aW9uIjp7IkRhdGVMZXNzVGhhbiI6eyJBV1M6RXBvY2hUaW1lIjoxNzk2MDgzMjAwfX19XX0_&Key-Pair-Id=K2QY5QTL8JSY6C&Signature=MEQCICpWD9JsxRQ0QmZZo7ZpMOmniwVHcCiyU2q05ZPoNhZlAiBpbJwY~yX0VrHxeYMzAYV0B9la92mwALG5lLqcIPhlFg__)

### Runtime and rendering

`index.html` mounts one canvas and `src/main.ts` owns the boot sequence: Rapier WASM init → world creation → base visuals → character → player model → input → legacy training UI → settings → mission controller → fixed-step frame loop.

- **Physics:** `src/physics.ts` uses Rapier's `KinematicCharacterController` at a fixed **1/60 s** timestep. The capsule is 1.6 m standing / 1.0 m crouching, radius 0.3 m, with explicit gravity (3.71 m/s²), jump velocity derived from jump height, slope limit (45°), autostep (0.3 m), and overhead-clearance checks before standing.
- **Interpolation:** physics steps are decoupled from rendering; the visual mesh is lerped between previous/current body positions. The follow camera uses a delayed target history (0.12 s), exponential smoothing, configurable framing and optional landing/running shake.
- **World:** the normal scene uses the supplied `Base.glb`. `authored-station.ts` removes the export's reference astronaut and door, splits the shell into floor/wall triangles, cuts a south doorway and farm approach, rebuilds matching Rapier trimesh collision, and fades walls for a cutaway when the player is inside. `?lab` swaps in the older primitive station and legacy exercises.
- **Assets:** `src/assets.ts` is a manifest for scale, yaw, offsets and animation clip names. Missing models fall back to a capsule astronaut; missing clips leave movement working. The player's hip translation is stripped at runtime so animation cannot fight the physics body.
- **Audio:** `src/audio.ts` synthesizes its own buffers with Web Audio (filtered noise grains, wind loop, sine alert). The nine WAV files in `public/audio/` are archived but not loaded by the current engine.

### Simulation

`src/base/model.ts` is the heart of the game and is deterministic and testable:

- **Power:** PV output = irradiance × area × efficiency × dust × incidence. Sun position and tracking angles come from `sunlight()`. Load shedding prioritizes essential base/shelter loads, then the oxygen plant, then crop growth. Battery charge/discharge honors limits and efficiencies; curtailment and unserved energy are tracked.
- **Integration:** `advance()` uses bounded 30-second midpoint quadrature and splits steps at battery/oxygen/dose boundaries. It is frame-schedule independent (tested).
- **Radiation:** baseline dose is integrated analytically; the 8.1 mGy event is a reconstructed triangular 8-hour profile, with modeled background subtracted to avoid double counting. Shielding transmission factors apply separately to baseline and event. Physical dose never decreases. The stress meter is explicitly fictional and recoverable.
- **Food:** harvest caps at 100, replants the bed, and regrowth only advances when the growing load is powered.
- **Legacy exercise:** `src/resources/simulation.ts` is a separate 120-second oxygen-on-a-battery puzzle with fictional units; it is preserved for regression testing and reachable through the legacy lab/debug route.

### UI and configuration

- `src/settings.ts` builds the single `lil-gui` window: movement, physics, camera, shake, player model/animation, audio, station view, rendering, presets/files, plus base and mission folders.
- `src/base/ui.ts` owns the base HUD (battery, oxygen, dose, stress, power flow, event state, cleaning progress) and base settings import/export.
- `src/mission.ts` owns the menu/tutorial/challenge/pause/results state machine, the bottom resource dock, crop beds, lander placement, dust particles and the debug event controls.
- All tuning validates ranges and round-trips through versioned JSON. Movement settings and base settings use separate local-storage keys and schemas.

## What is strong

- **Genuine systems trade-offs**, not a Mars-themed reskin: oxygen needs power, crops need power, dust reduces generation, night needs storage, and shelter costs life-support load.
- **Honest science labeling:** the RAD reference, reconstructed event curve, fictional stress meter, game-balance crop rates and operational dose limit are all distinguished in UI and docs.
- **Deterministic, well-tested simulation:** 41 unit tests cover energy conservation, dose normalization, boundary failures, shelter geometry, frame independence, cleaning cancellation, crop regrowth and a documented survivable strategy.
- **Real browser coverage:** 15 Playwright tests exercise menu flow, movement, jump/crouch, solar cleaning, shelter entry, base GLB traversal, media loading, debug disasters, loss/restart and responsive viewport.
- **Clean handoff story:** replaceable GLBs, manifest-driven transforms/clips, a documented modeler convention, and placeholder fallbacks.

## Observations and risks

| Severity | Finding | Detail |
| --- | --- | --- |
| Medium | **README is stale** | It still describes the two-minute resource exercise and primitive station as the main experience, and says WAVs are the default audio. `GAMEPLAY.md` reflects the shipped game. A newcomer reading README first will be confused. |
| Medium | **5.11 MB single JS chunk** | Rapier's compat build embeds WASM in the bundle. On slow mobile connections the first load is heavy. Consider `@dimforge/rapier3d` with a separate `.wasm` asset and dynamic import/code splitting. |
| Medium | **No touch controls or mission save** | Explicitly documented. The audience includes ages 7–12, many of whom are on tablets/phones; the responsive layout works, but play needs a keyboard. |
| Low–Medium | **Jump and crouch have no authored clips** | The supplied `player.glb` contains `Idle`, `walk again`, `Action.001`, `Armature.001\|mixamo.com\|Layer0`. `Jump` and `Crouch` are missing and fall back to the idle pose, so those actions look stiff. |
| Low | **Legacy `?lab` mode is visually rough** | World-space labels overlap the header, wall panel UVs look oversized, and software rendering reports very low FPS. The normal game is clearly the polished path; the lab is a regression sandbox. |
| Low | **Debug button pauses but closing it does not resume** | Opening Debug pauses; closing it leaves the pause overlay, requiring a separate Resume click. Functional, but an extra step. |
| Low | **Unused WAV assets** | ~900 KB of user-supplied audio ships in `public/audio/` but the current engine synthesizes sound. Either load them as an optional pack or move them out of the deployed bundle. |
| Low | **Interaction routing is permissive** | `base.interact()` returns `true` whenever the base is active, even if no target is in range. Mission-specific interactions are checked first, so this mainly affects stray E presses. A shared interaction resolver would make target selection explicit. |

## Suggested next steps

1. **Rewrite README as a short onboarding document** (what the game is, how to run, controls, test commands) and move the changelog/handoff detail into `docs/`.
2. **Add or map `Jump` and `Crouch` clips**, or generate simple procedural poses, so the two missing states no longer snap to idle.
3. **Split the production bundle** and load Rapier's WASM separately; this is the single biggest loading-cost improvement.
4. **Add a "Skip tutorial" / resume-progress path** for returning players, and persist tutorial completion locally.
5. **Unify world interaction targeting** into one resolver with distance/height checks and a single prompt, then reuse it for array, oxygen, crops, beacon and shelter.
6. **Decide the mobile story:** either add a minimal touch layer (virtual stick + action buttons) or clearly gate the experience to keyboard devices.
7. **Optional:** add curated NASA imagery/source credits and a compact "science" panel; the data-provenance groundwork is already there.

## Screenshots

| Title / menu | Tutorial dialogue |
| --- | --- |
| ![Menu](https://private-us-east-1.manuscdn.com/sessionFile/6E54TNmq5u8RErGC3f6Mds/sandbox/b3cwZ2mTTU2sxjH7GUAWfn-images_1794636574759_na1fn_L2hvbWUvdWJ1bnR1L25lYnVsYS9zaG90cy8wMS1tZW51.png?Policy=eyJTdGF0ZW1lbnQiOlt7IlJlc291cmNlIjoiaHR0cHM6Ly9wcml2YXRlLXVzLWVhc3QtMS5tYW51c2Nkbi5jb20vc2Vzc2lvbkZpbGUvNkU1NFRObXE1dThSRXJHQzNmNk1kcy9zYW5kYm94L2IzY3daMm1UVFUyc3hqSDdHVUFXZm4taW1hZ2VzXzE3OTQ2MzY1NzQ3NTlfbmExZm5fTDJodmJXVXZkV0oxYm5SMUwyNWxZblZzWVM5emFHOTBjeTh3TVMxdFpXNTEucG5nIiwiQ29uZGl0aW9uIjp7IkRhdGVMZXNzVGhhbiI6eyJBV1M6RXBvY2hUaW1lIjoxNzk2MDgzMjAwfX19XX0_&Key-Pair-Id=K2QY5QTL8JSY6C&Signature=MEUCIQCJJrnCZJ5jagXKrJczNQqTaFvlYsaw2UZ0NEnJ9pa~7QIgZ8G4aLp7rtdBpjnosyKfekYLlLajbNmHk8wxsxH1pAM_) | ![Tutorial](https://private-us-east-1.manuscdn.com/sessionFile/6E54TNmq5u8RErGC3f6Mds/sandbox/b3cwZ2mTTU2sxjH7GUAWfn-images_1794636574759_na1fn_L2hvbWUvdWJ1bnR1L25lYnVsYS9zaG90cy8wMi10dXRvcmlhbC1kaWFsb2d1ZQ.png?Policy=eyJTdGF0ZW1lbnQiOlt7IlJlc291cmNlIjoiaHR0cHM6Ly9wcml2YXRlLXVzLWVhc3QtMS5tYW51c2Nkbi5jb20vc2Vzc2lvbkZpbGUvNkU1NFRObXE1dThSRXJHQzNmNk1kcy9zYW5kYm94L2IzY3daMm1UVFUyc3hqSDdHVUFXZm4taW1hZ2VzXzE3OTQ2MzY1NzQ3NTlfbmExZm5fTDJodmJXVXZkV0oxYm5SMUwyNWxZblZzWVM5emFHOTBjeTh3TWkxMGRYUnZjbWxoYkMxa2FXRnNiMmQxWlEucG5nIiwiQ29uZGl0aW9uIjp7IkRhdGVMZXNzVGhhbiI6eyJBV1M6RXBvY2hUaW1lIjoxNzk2MDgzMjAwfX19XX0_&Key-Pair-Id=K2QY5QTL8JSY6C&Signature=MEQCICbeKLgcPLtbqCEbxiyHmrAJq8V360Z90VK9dT-ob16aAiBGKRkx8WBqoRE91DF8~z5kmO~011Rfm-1xT5MaXbkXTQ__) |

| Tutorial world task | Pause overlay |
| --- | --- |
| ![Tutorial world](https://private-us-east-1.manuscdn.com/sessionFile/6E54TNmq5u8RErGC3f6Mds/sandbox/b3cwZ2mTTU2sxjH7GUAWfn-images_1794636574759_na1fn_L2hvbWUvdWJ1bnR1L25lYnVsYS9zaG90cy8wMy10dXRvcmlhbC13b3JsZA.png?Policy=eyJTdGF0ZW1lbnQiOlt7IlJlc291cmNlIjoiaHR0cHM6Ly9wcml2YXRlLXVzLWVhc3QtMS5tYW51c2Nkbi5jb20vc2Vzc2lvbkZpbGUvNkU1NFRObXE1dThSRXJHQzNmNk1kcy9zYW5kYm94L2IzY3daMm1UVFUyc3hqSDdHVUFXZm4taW1hZ2VzXzE3OTQ2MzY1NzQ3NTlfbmExZm5fTDJodmJXVXZkV0oxYm5SMUwyNWxZblZzWVM5emFHOTBjeTh3TXkxMGRYUnZjbWxoYkMxM2IzSnNaQS5wbmciLCJDb25kaXRpb24iOnsiRGF0ZUxlc3NUaGFuIjp7IkFXUzpFcG9jaFRpbWUiOjE3OTYwODMyMDB9fX1dfQ__&Key-Pair-Id=K2QY5QTL8JSY6C&Signature=MEUCIQDruT3bBbxU0Y7Fx1OXxoZFLSYVzVzkFvNWFEjwxauWjQIgMcG6E3ZtgQatQ5SzZ1quFZyXeZMFhL9ECBrZDud9anY_) | ![Paused](https://private-us-east-1.manuscdn.com/sessionFile/6E54TNmq5u8RErGC3f6Mds/sandbox/b3cwZ2mTTU2sxjH7GUAWfn-images_1794636574759_na1fn_L2hvbWUvdWJ1bnR1L25lYnVsYS9zaG90cy8wNC1wYXVzZWQ.png?Policy=eyJTdGF0ZW1lbnQiOlt7IlJlc291cmNlIjoiaHR0cHM6Ly9wcml2YXRlLXVzLWVhc3QtMS5tYW51c2Nkbi5jb20vc2Vzc2lvbkZpbGUvNkU1NFRObXE1dThSRXJHQzNmNk1kcy9zYW5kYm94L2IzY3daMm1UVFUyc3hqSDdHVUFXZm4taW1hZ2VzXzE3OTQ2MzY1NzQ3NTlfbmExZm5fTDJodmJXVXZkV0oxYm5SMUwyNWxZblZzWVM5emFHOTBjeTh3TkMxd1lYVnpaV1EucG5nIiwiQ29uZGl0aW9uIjp7IkRhdGVMZXNzVGhhbiI6eyJBV1M6RXBvY2hUaW1lIjoxNzk2MDgzMjAwfX19XX0_&Key-Pair-Id=K2QY5QTL8JSY6C&Signature=MEUCIQDAvEDfzdmMmI~UtfownrK9Ems6CnpRAC1wWHGM1ehclgIgOONm3ZBnlxWyPWeJauuqw1KZ-M~J4QkeO540DoMzC1E_) |

| Challenge HUD | Walking the base |
| --- | --- |
| ![Mission](https://private-us-east-1.manuscdn.com/sessionFile/6E54TNmq5u8RErGC3f6Mds/sandbox/b3cwZ2mTTU2sxjH7GUAWfn-images_1794636574759_na1fn_L2hvbWUvdWJ1bnR1L25lYnVsYS9zaG90cy8wNS1taXNzaW9u.png?Policy=eyJTdGF0ZW1lbnQiOlt7IlJlc291cmNlIjoiaHR0cHM6Ly9wcml2YXRlLXVzLWVhc3QtMS5tYW51c2Nkbi5jb20vc2Vzc2lvbkZpbGUvNkU1NFRObXE1dThSRXJHQzNmNk1kcy9zYW5kYm94L2IzY3daMm1UVFUyc3hqSDdHVUFXZm4taW1hZ2VzXzE3OTQ2MzY1NzQ3NTlfbmExZm5fTDJodmJXVXZkV0oxYm5SMUwyNWxZblZzWVM5emFHOTBjeTh3TlMxdGFYTnphVzl1LnBuZyIsIkNvbmRpdGlvbiI6eyJEYXRlTGVzc1RoYW4iOnsiQVdTOkVwb2NoVGltZSI6MTc5NjA4MzIwMH19fV19&Key-Pair-Id=K2QY5QTL8JSY6C&Signature=MEUCIQCKgcZaTLfX-AHSA9nTqQqxoNmpPGiipDuKPdWBRjnwkAIgNx0ZeJSX9sjZ3ttUOVNt8q8r5ODUHndkaxLzWt8iZ1I_) | ![Mission walk](https://private-us-east-1.manuscdn.com/sessionFile/6E54TNmq5u8RErGC3f6Mds/sandbox/b3cwZ2mTTU2sxjH7GUAWfn-images_1794636574759_na1fn_L2hvbWUvdWJ1bnR1L25lYnVsYS9zaG90cy8wNi1taXNzaW9uLXdhbGs.png?Policy=eyJTdGF0ZW1lbnQiOlt7IlJlc291cmNlIjoiaHR0cHM6Ly9wcml2YXRlLXVzLWVhc3QtMS5tYW51c2Nkbi5jb20vc2Vzc2lvbkZpbGUvNkU1NFRObXE1dThSRXJHQzNmNk1kcy9zYW5kYm94L2IzY3daMm1UVFUyc3hqSDdHVUFXZm4taW1hZ2VzXzE3OTQ2MzY1NzQ3NTlfbmExZm5fTDJodmJXVXZkV0oxYm5SMUwyNWxZblZzWVM5emFHOTBjeTh3TmkxdGFYTnphVzl1TFhkaGJHcy5wbmciLCJDb25kaXRpb24iOnsiRGF0ZUxlc3NUaGFuIjp7IkFXUzpFcG9jaFRpbWUiOjE3OTYwODMyMDB9fX1dfQ__&Key-Pair-Id=K2QY5QTL8JSY6C&Signature=MEQCIAckfP~tdFc-JF5kurCOfEj~okqQDoxJ8ZFT4~~WuQWkAiBNBkiVPlrrGG9jGzVIUd0NCVd6-jJK0J1iPRjLgvT-tw__) |

| Legacy `?lab` sandbox | Mobile menu |
| --- | --- |
| ![Lab](https://private-us-east-1.manuscdn.com/sessionFile/6E54TNmq5u8RErGC3f6Mds/sandbox/b3cwZ2mTTU2sxjH7GUAWfn-images_1794636574759_na1fn_L2hvbWUvdWJ1bnR1L25lYnVsYS9zaG90cy8wNy1sYWI.png?Policy=eyJTdGF0ZW1lbnQiOlt7IlJlc291cmNlIjoiaHR0cHM6Ly9wcml2YXRlLXVzLWVhc3QtMS5tYW51c2Nkbi5jb20vc2Vzc2lvbkZpbGUvNkU1NFRObXE1dThSRXJHQzNmNk1kcy9zYW5kYm94L2IzY3daMm1UVFUyc3hqSDdHVUFXZm4taW1hZ2VzXzE3OTQ2MzY1NzQ3NTlfbmExZm5fTDJodmJXVXZkV0oxYm5SMUwyNWxZblZzWVM5emFHOTBjeTh3Tnkxc1lXSS5wbmciLCJDb25kaXRpb24iOnsiRGF0ZUxlc3NUaGFuIjp7IkFXUzpFcG9jaFRpbWUiOjE3OTYwODMyMDB9fX1dfQ__&Key-Pair-Id=K2QY5QTL8JSY6C&Signature=MEQCIFWjE2KfsLh5tymP2mvrmBG64N8v0c~Cifgc1ZzCwnrRAiAWjBFueo2Xo3a8B8q0yii4f3GKQLYWlADfqDqcnc7hNQ__) | ![Mobile](https://private-us-east-1.manuscdn.com/sessionFile/6E54TNmq5u8RErGC3f6Mds/sandbox/b3cwZ2mTTU2sxjH7GUAWfn-images_1794636574759_na1fn_L2hvbWUvdWJ1bnR1L25lYnVsYS9zaG90cy8wOC1tb2JpbGUtbWVudQ.png?Policy=eyJTdGF0ZW1lbnQiOlt7IlJlc291cmNlIjoiaHR0cHM6Ly9wcml2YXRlLXVzLWVhc3QtMS5tYW51c2Nkbi5jb20vc2Vzc2lvbkZpbGUvNkU1NFRObXE1dThSRXJHQzNmNk1kcy9zYW5kYm94L2IzY3daMm1UVFUyc3hqSDdHVUFXZm4taW1hZ2VzXzE3OTQ2MzY1NzQ3NTlfbmExZm5fTDJodmJXVXZkV0oxYm5SMUwyNWxZblZzWVM5emFHOTBjeTh3T0MxdGIySnBiR1V0YldWdWRRLnBuZyIsIkNvbmRpdGlvbiI6eyJEYXRlTGVzc1RoYW4iOnsiQVdTOkVwb2NoVGltZSI6MTc5NjA4MzIwMH19fV19&Key-Pair-Id=K2QY5QTL8JSY6C&Signature=MEUCIQDDBCe5aWbkr71GdwM11mpGyJs20lim-NXZraxcrcUjegIgDc58-xYRymxpWqMm-74jtK4gmQ5JPpQ9A7S7pUthWHA_) |

## Key files to read first

| File | Why |
| --- | --- |
| `src/main.ts` | Boot, frame loop, system wiring, debug telemetry |
| `src/base/model.ts` | Power, oxygen, dose, stress, crops — the game's core |
| `src/base/config.ts` | Every scenario parameter and validation range |
| `src/mission.ts` | Menu/tutorial/challenge/pause/results state machine |
| `src/physics.ts` | Rapier kinematic character controller |
| `src/authored-station.ts` | GLB shell splitting, doorway cut, trimesh collision, cutaway |
| `src/assets.ts` | Player model normalization and animation mapping |
| `src/base/ui.ts` | Base HUD, settings, import/export, interaction targets |
| `GAMEPLAY.md` | Most accurate description of shipped behavior |
| `MAIN_GAME_PLAN.md` | Design rationale and scope decisions |
