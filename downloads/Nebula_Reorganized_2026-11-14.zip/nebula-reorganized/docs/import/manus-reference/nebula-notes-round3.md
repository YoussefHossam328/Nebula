# Nebula round 3 notes (terrain, APOD, knees)
User NASA key: [REDACTED_API_KEY] (api.nasa.gov, 10000/h). Do NOT commit to repo.

## APOD
- api.nasa.gov/planetary/apod responds (CORS *), but EVERY date returns placeholder: title "NASA Science", url https://science.nasa.gov/wp-content/themes/nasa-child/assets/images/nasa-logo@2x.png, generic explanation "Discover the cosmos!...". Today (no date) -> 500.
- Cause: apod.nasa.gov now 301-redirects -> https://science.nasa.gov/apod/ ; apod.nasa.gov/apod/apYYMMDD.html -> https://science.nasa.gov/image-article/apod-2025-october-1-<slug>/
- Article page: og:title "APOD: 2025 October 1 - NGC 6960: The Witchs Broom Nebula - NASA Science"; og:image https://assets.science.nasa.gov/content/dam/science/cds/apod/apod/2025/october/WitchBroom_Meyers_6043.jpg/jcr:content/renditions/cq5dam.web.1280.1280.jpeg ; text "Explanation: ..." ; "Image Credit & Copyright: Brian Meyers" ; "Authors & editors: Robert Nemiroff ..."

## Terrain
- Source bucket listing: https://asc-pds-services.s3.us-west-2.amazonaws.com/?list-type=2&prefix=mosaic/mars2020_trn/ (planetarymaps.usgs.gov/mosaic/mars2020_trn/ links there)
- DEM: .../mosaic/mars2020_trn/CTX/JEZ_ctx_B_soc_008_DTM_MOLAtopography_DeltaGeoid_20m_Eqc_latTs0_lon0.tif (9.6MB, 1596x1512, 20m, ESRI:103885 equirect, nodata -3.4e38, elev -2711..-1516)
- Ortho: .../CTX/JEZ_ctx_B_soc_008_orthoMosaic_6m_Eqc_latTs0_lon0.tif (6m, uint8)
- Also HiRISE 1m: .../HiRISE/DTM_MOLAtopography_DeltaGeoid_Jezero_C_Edited_affine_1m_Eqc_latTs0_lon0.tif (125MB) etc.
- Chosen site DEM row 382 col 262 -> 18.59213N 77.24904E, elev -2290.8 m, window 241x241 (4.8 km), relief -16..+368 m. ~22 km from Jezero centre (18.38N 77.58E) = western rim area. Ortho shows dune-floored valley, knobby terrain, scarp to north.
- Mars Trek (trek.nasa.gov) WMTS only serves rendered image tiles. Global MOLA 463 m/px too coarse.
- Baked: public/terrain/{site.json,heights.bin,ortho.jpg} via scripts/bake-terrain.py (rasterio /vsicurl).

## Rapier heightfield
- heightfield(nrows=N-1, ncols=N-1, heights column-major idx=c*N+r, scale {x:extent,y:1,z:extent}); column<->x, row<->z verified on 5x5.

## Knees
- probe: crouch was -0.21 (backward); flipped proceduralPose signs (upLeg +, leg -, foot +) -> +0.23 crouch, +0.16 jump. Fixed.
