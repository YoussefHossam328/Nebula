Missing from the Manus upload: archive.json and its dated image files. See docs/import/RECOVERY_REPORT.md. No fabricated APOD records are supplied here.
