Missing from the Manus upload: site.json, heights.bin, ortho.jpg. See docs/import/RECOVERY_REPORT.md. No generated or substitute terrain data is supplied here.
