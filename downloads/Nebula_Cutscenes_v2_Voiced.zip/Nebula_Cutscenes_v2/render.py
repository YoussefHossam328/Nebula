from pathlib import Path
import subprocess,json,textwrap,shutil,zipfile
from concurrent.futures import ThreadPoolExecutor
ROOT=Path(__file__).resolve().parent
WORK=ROOT.parent/'.nebula-cutscene-work-v2';WORK.mkdir(exist_ok=True)
for folder in ['images','clips','subtitles']: (ROOT/folder).mkdir(exist_ok=True)
CHAPTERS=[
('01_arrival','A STORY FROM MARS','Before tutorial: movement',[
 ('bedroom',5,'SON','Dad, what was it like living on Mars?'),
 ('bedroom',5,'DAD','Let me tell you about the base we looked after.'),
 ('exterior',5,'DAD','First, I learned to move safely in my suit.'),
 ('exterior',5,'DAD','On Mars, even a short walk takes planning.')]),
('02_sunlight','CATCH THE SUNLIGHT','Before tutorial: solar power',[
 ('bedroom',5,'SON','How did you keep the lights on?'),
 ('exterior',9,'DAD','Sunlight charged our batteries. We saved that power for the night.')]),
('03_dust','A LITTLE DUST, A BIG DIFFERENCE','Before tutorial: panel cleaning',[
 ('bedroom',5,'SON','What happened when the panels got dusty?'),
 ('exterior',7,'DAD','Dust blocked the sunlight. Cleaning helped us make more power.')]),
('04_oxygen','EVERY BREATH NEEDS POWER','Before tutorial: oxygen',[
 ('bedroom',5,'SON','And how did you get air to breathe?'),
 ('interior',9,'DAD','Our oxygen maker needed electricity. We watched both supplies carefully.')]),
('05_food','GROWING TOMORROW','Before tutorial: food production',[
 ('bedroom',5,'SON','Did you grow your dinner there?'),
 ('interior',9,'DAD','Yes. Our crops needed light and time. We planned the power for each harvest.')]),
('06_shelter','KNOW WHEN TO GO INSIDE','Before tutorial: radiation and shelter',[
 ('bedroom',5,'SON','What did you do when a space-weather warning arrived?'),
 ('exterior',11,'DAD','We went to shelter. Shielding reduced new radiation exposure. It could not erase the dose we already received.')]),
('07_messages','EARTH IS FAR AWAY','Before tutorial: communication delay',[
 ('bedroom',5,'SON','Could you ask Earth for help right away?'),
 ('interior',11,'DAD','We could send a message, but the reply took time. We kept checking the base while we waited.')]),
('08_dream','NOW IT IS YOUR TURN','After final tutorial; before seven-sol challenge',[
 ('bedroom',5,'DAD','That is how we cared for our home on Mars. Good night, explorer.'),
 ('dream',7,'STORY','As the story ended, his eyes closed. The adventure stayed with him.'),
 ('dream',6,'STORY','In his dream, he had a Mars base of his own to look after.'),
 ('exterior',6,'MISSION','Seven sols. Food, oxygen and power. What will you choose?')]),
]

if (ROOT/"dialogue-timing.json").exists(): CHAPTERS=json.loads((ROOT/"dialogue-timing.json").read_text())

def ass_time(t):
 h=int(t//3600);m=int(t%3600//60);s=t%60;return f'{h}:{m:02d}:{s:05.2f}'
def srt_time(t):
 return f'{int(t//3600):02d}:{int(t%3600//60):02d}:{int(t%60):02d},{round((t%1)*1000):03d}'
def text_lines(s):return r'\N'.join(textwrap.wrap(s,66))
HEADER='''[Script Info]
ScriptType: v4.00+
PlayResX: 1280
PlayResY: 720
WrapStyle: 0
[V4+ Styles]
Format: Name, Fontname, Fontsize, PrimaryColour, SecondaryColour, OutlineColour, BackColour, Bold, Italic, Underline, StrikeOut, ScaleX, ScaleY, Spacing, Angle, BorderStyle, Outline, Shadow, Alignment, MarginL, MarginR, MarginV, Encoding
Style: Dialogue,DejaVu Sans,29,&H00FFFFFF,&H00FFFFFF,&H90201A14,&H90201A14,0,0,0,0,100,100,0,0,3,9,0,2,64,64,42,1
Style: Chapter,DejaVu Sans,19,&H00D8EBDD,&H00FFFFFF,&H90201A14,&H90201A14,1,0,0,0,100,100,1.5,0,3,6,0,7,40,40,32,1
[Events]
Format: Layer, Start, End, Style, Name, MarginL, MarginR, MarginV, Effect, Text
'''

def render_one(job):
 key,title,duration,image,speaker,line,index=job
 output=WORK/f'{key}-{index}.mp4';ass=WORK/f'{key}-{index}.ass'
 ass.write_text(HEADER+f'Dialogue: 1,0:00:00.00,{ass_time(duration)},Dialogue,,0,0,0,,{speaker}: {text_lines(line)}\n')
 focusx=.5 if image in ['bedroom','dream'] else (.62 if key in ['02_sunlight','03_dust','05_food'] else .4)
 vf=f"scale=1672:942,zoompan=z='1.015+0.00012*on':x='(iw-iw/zoom)*{focusx}':y='(ih-ih/zoom)*0.42':d=1:s=1280x720:fps=24,subtitles={ass},fade=t=in:st=0:d=0.35,fade=t=out:st={duration-.4}:d=0.4,format=yuv420p"
 args=['ffmpeg','-hide_banner','-loglevel','error','-y','-loop','1','-framerate','24','-i',str(ROOT/'images'/f'{image}.png'),'-i',str(ROOT/'voice'/f'{key}-{index}.wav'),'-vf',vf,'-af',f'loudnorm=I=-18:TP=-1.5:LRA=7,adelay=550,apad,afade=t=out:st={duration-.25}:d=0.25', '-t',str(duration),'-c:v','libx264','-preset','veryfast','-crf','20','-threads','2','-c:a','aac','-b:a','128k','-ar','48000','-ac','2','-movflags','+faststart',str(output)]
 subprocess.run(args,check=True);print('Rendered',output.name,flush=True);return output

def concat(paths,out):
 listing=WORK/(out.stem+'.list');listing.write_text(''.join("file '"+str(p)+"'\n" for p in paths))
 subprocess.run(['ffmpeg','-hide_banner','-loglevel','error','-y','-f','concat','-safe','0','-i',str(listing),'-c','copy','-movflags','+faststart',str(out)],check=True)

jobs=[]
for key,title,slot,shots in CHAPTERS:
 for i,(image,duration,speaker,line) in enumerate(shots):jobs.append((key,title,duration,image,speaker,line,i))
with ThreadPoolExecutor(max_workers=2) as pool:list(pool.map(render_one,jobs))
clips=[];manifest=[];all_srt=[];global_time=0;cue_number=1
for key,title,slot,shots in CHAPTERS:
 out=ROOT/'clips'/f'{key}.mp4';concat([WORK/f'{key}-{i}.mp4' for i in range(len(shots))],out);clips.append(out)
 t=0;srt=[]
 for i,(_,duration,speaker,line) in enumerate(shots):
  body=speaker+': '+line
  srt.append(f'{i+1}\n{srt_time(t)} --> {srt_time(t+duration)}\n{body}\n')
  all_srt.append(f'{cue_number}\n{srt_time(global_time+t)} --> {srt_time(global_time+t+duration)}\n{body}\n');cue_number+=1;t+=duration
 (ROOT/'subtitles'/f'{key}.srt').write_text('\n'.join(srt))
 manifest.append(dict(file='clips/'+out.name,title=title,slot=slot,durationSeconds=t,previewStartSeconds=global_time,dialogue=[dict(image=i,durationSeconds=d,speaker=s,text=line) for i,d,s,line in shots]));global_time+=t
concat(clips,ROOT/'Nebula_Bedtime_to_Mars_Preview.mp4')
(ROOT/'subtitles'/'Nebula_Preview.srt').write_text('\n'.join(all_srt))
(ROOT/'manifest.json').write_text(json.dumps(dict(format='1280x720, 24 fps, H.264 MP4, synthetic voice-over AAC stereo',totalSeconds=global_time,clips=manifest),indent=2))
print('Finished',global_time,'seconds',flush=True)
