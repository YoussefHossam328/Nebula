"""Generate local synthetic narration. Install kokoro-onnx and soundfile first.
Set KOKORO_MODELS to a directory with kokoro-v1.0.int8.onnx and voices-v1.0.bin.
"""
from pathlib import Path
import ast,os,json
import soundfile as sf
from kokoro_onnx import Kokoro
ROOT=Path(__file__).resolve().parent
models=Path(os.environ.get('KOKORO_MODELS', '/workspace/artifacts/tts-models'))
k=Kokoro(str(models/'kokoro-v1.0.int8.onnx'),str(models/'voices-v1.0.bin'))
chapters=next(ast.literal_eval(n.value) for n in ast.parse((ROOT/'render.py').read_text()).body if isinstance(n,ast.Assign) and any(isinstance(t,ast.Name) and t.id=='CHAPTERS' for t in n.targets))
voices={'SON':('am_puck',.88),'DAD':('am_michael',.86),'STORY':('af_heart',.90),'MISSION':('am_michael',.86)}
records=[];updated=[]
for key,title,slot,shots in chapters:
 new_shots=[]
 for i,(image,duration,speaker,line) in enumerate(shots):
  voice,speed=voices[speaker]
  audio,sr=k.create(line,voice=voice,speed=speed,lang='en-us',sentence_pause=.3,clause_pause=.12)
  dest=ROOT/'voice'/f'{key}-{i}.wav';sf.write(str(dest),audio,sr,subtype='PCM_16')
  seconds=len(audio)/sr
  # Keep the original gentle pacing; extend rather than cut a spoken line.
  duration=max(duration,round(seconds+1.15,2))
  new_shots.append([image,duration,speaker,line]);records.append(dict(file=str(dest.relative_to(ROOT)),speaker=speaker,voice=voice,speed=speed,spokenSeconds=seconds,shotSeconds=duration,text=line))
  print(key,i,speaker,round(seconds,2),'seconds',flush=True)
 updated.append([key,title,slot,new_shots])
(ROOT/'dialogue-timing.json').write_text(json.dumps(updated,indent=2))
(ROOT/'voice'/'voice_manifest.json').write_text(json.dumps(dict(engine='Kokoro-82M through kokoro-onnx, local inference',voices=voices,lines=records),indent=2))
