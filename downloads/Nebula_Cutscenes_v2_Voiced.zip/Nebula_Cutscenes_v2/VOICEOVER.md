# Synthetic voice-over credits

Generated locally with Kokoro-82M v1.0 (int8 ONNX) using kokoro-onnx. These are stock synthetic voices, not recordings or clones of the user, a real astronaut, or any named actor.

- Dad and mission prompt: `am_michael`, speed 0.86.
- Son: `am_puck`, speed 0.88, a lighter contrasting synthetic voice.
- Story narrator: `af_heart`, speed 0.90.

Each line starts 0.55 seconds into its shot. Shots are extended when necessary to preserve the complete line. Voice gain is normalized toward -18 LUFS with a -1.5 dB true-peak target. WAV masters are 24 kHz mono PCM; the MP4 mix is AAC stereo at 48 kHz.

Sources:
- Model: https://huggingface.co/hexgrad/Kokoro-82M (model card identifies Apache-2.0 licensing).
- Runtime: https://github.com/thewh1teagle/kokoro-onnx (MIT).
- Model files: https://github.com/thewh1teagle/kokoro-onnx/releases/tag/model-files-v1.0

Model weights and the Python environment are not included in the ZIP. To regenerate audio, install `kokoro-onnx` and `soundfile`, download the model and voices, and set `KOKORO_MODELS` to that directory before running make_voiceover.py. Re-rendering with the supplied WAVs needs only Python 3 and FFmpeg with libass/libx264.

No changes were made to the game or its deployment for this delivery. The original version 1 files are preserved separately.
