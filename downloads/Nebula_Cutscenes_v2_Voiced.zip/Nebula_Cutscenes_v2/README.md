# Nebula — Bedtime to Mars, voiced illustrated cutscenes v2

A retired astronaut tells his son about maintaining a Mars base. Each memory leads into a tutorial. After training, the son falls asleep and dreams the seven-sol challenge.

These are AI-illustrated motion cutscenes: gentle camera movement, fades and burned-in dialogue captions. They are not fully animated character performances. Version 2 adds distinct synthetic voices for Dad, Son and the narrator. There is no music. All top-left chapter titles have been removed; bottom dialogue captions remain. All imagery is fictional concept art generated for this story, not NASA photography, a historical mission record, or NASA endorsement.

## Files and placement

- `01_arrival.mp4`: before movement tutorial. Introduces Dad, Son and Mars.
- `02_sunlight.mp4`: before solar/battery tutorial.
- `03_dust.mp4`: before panel cleaning tutorial.
- `04_oxygen.mp4`: before oxygen tutorial.
- `05_food.mp4`: before crops/nourishment tutorial.
- `06_shelter.mp4`: before radiation/shelter tutorial. Shelter reduces new exposure; it does not erase recorded physical dose.
- `07_messages.mp4`: before communication delay tutorial.
- `08_dream.mp4`: AFTER the final tutorial/mission briefing, immediately before the seven-sol challenge.

Files are in `clips/`. The combined preview is supplied as a separate download. It plays clips back-to-back for review; in the game, tutorials should interrupt the story at the indicated slots.

The eight clips total about 2 minutes 11 seconds. Format: 1280×720, 24 fps, H.264 MP4, yuv420p, AAC stereo voice-over audio, fast-start metadata for browser playback.

`manifest.json` contains dialogue, chapter order, intended placement and nominal timings. `subtitles/` contains sidecar SRT captions. MP4 captions are already burned in; do not simultaneously display the SRT unless using it to replace the video captions in a later render.

`images/` contains the four source illustrations. `render.py` rebuilds the clips using Python 3 and FFmpeg with libass/libx264, and creates the combined preview. Character designs, palette and dialogue are a first draft and can be revised.

`voice/` contains editable voice WAVs and a voice manifest. `make_voiceover.py` regenerates the voices locally using Kokoro. `dialogue-timing.json` extends shots where needed so spoken lines are not cut off. See VOICEOVER.md for engine and voice credits.

No game files were changed or published for this delivery.
